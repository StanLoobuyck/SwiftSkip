const OFFSCREEN_DOCUMENT_PATH = "offscreen.html";

let creatingOffscreenDocument = null;
let offscreenDocumentReady = false;
const lectureDownloadState = {
  available: false,
  active: false,
  jobId: null,
  url: null,
  title: null,
  tabId: null,
  phase: "No lecture detected",
  downloaded: 0,
  total: 0,
  percent: 0,
  fallback: null,
  error: null,
};

async function hasOffscreenDocument() {
  if (!chrome.runtime.getContexts) {
    return false;
  }

  const documentUrl = chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH);
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [documentUrl],
  });

  return contexts.length > 0;
}

async function ensureOffscreenDocument() {
  if (offscreenDocumentReady || (await hasOffscreenDocument())) {
    offscreenDocumentReady = true;
    return;
  }

  if (!creatingOffscreenDocument) {
    creatingOffscreenDocument = chrome.offscreen.createDocument({
      url: OFFSCREEN_DOCUMENT_PATH,
      reasons: ["BLOBS"],
      justification: "Create a local video blob from Kaltura HLS lecture segments.",
    });
  }

  try {
    await creatingOffscreenDocument;
    offscreenDocumentReady = true;
  } finally {
    creatingOffscreenDocument = null;
  }
}

function sanitizeFilename(title) {
  const fallback = "lecture";
  const safeTitle = String(title || fallback)
    .replace(/[<>:"/\\|?*\x00-\x1f]/g, "_")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 100);

  return safeTitle || fallback;
}

function downloadFile({ url, filename, saveAs = false }) {
  return new Promise((resolve, reject) => {
    chrome.downloads.download({ url, filename, saveAs }, (downloadId) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }

      resolve(downloadId);
    });
  });
}

function createJobId() {
  return `swiftskip-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function getPublicDownloadState() {
  return { ...lectureDownloadState };
}

function publishDownloadState() {
  const state = getPublicDownloadState();
  const shouldNotifyTab =
    state.active ||
    ["Complete", "Canceled", "Saved playlist", "Download failed"].includes(
      state.phase,
    );

  if (state.tabId && shouldNotifyTab) {
    chrome.tabs.sendMessage(state.tabId, {
      action: "lectureDownloadProgress",
      ...state,
    }).catch(() => {
      /* The lecture tab may have navigated or no longer have the content script. */
    });
  }

  chrome.runtime.sendMessage({
    action: "lectureDownloadStateChanged",
    state,
  }).catch(() => {
    /* No popup or extension page is currently listening. */
  });
}

function setDownloadState(patch, shouldPublish = true) {
  Object.assign(lectureDownloadState, patch);
  if (shouldPublish) {
    publishDownloadState();
  }
  return getPublicDownloadState();
}

async function startLectureDownload({ url, title, tabId, jobId }) {
  if (lectureDownloadState.active) {
    return getPublicDownloadState();
  }

  const resolvedUrl = url || lectureDownloadState.url;
  if (!resolvedUrl) {
    return setDownloadState({
      available: false,
      active: false,
      phase: "No lecture detected",
      error: "No lecture stream has been detected yet.",
    });
  }

  const resolvedTitle = sanitizeFilename(title || lectureDownloadState.title);
  const resolvedTabId = tabId || lectureDownloadState.tabId;
  const resolvedJobId = jobId || createJobId();

  setDownloadState({
    available: true,
    active: true,
    jobId: resolvedJobId,
    url: resolvedUrl,
    title: resolvedTitle,
    tabId: resolvedTabId,
    phase: "Preparing",
    downloaded: 0,
    total: 0,
    percent: 0,
    fallback: null,
    error: null,
  });

  await ensureOffscreenDocument();

  const response = await chrome.runtime.sendMessage({
    action: "offscreenDownloadLecture",
    url: resolvedUrl,
    title: resolvedTitle,
    tabId: resolvedTabId,
    jobId: resolvedJobId,
  });

  if (response && response.canceled) {
    return setDownloadState({
      active: false,
      phase: "Canceled",
      percent: 0,
      error: null,
    });
  }

  if (response && response.fallback) {
    return setDownloadState({
      active: false,
      phase: "Saved playlist",
      percent: 0,
      fallback: response.fallback,
      error: response.error || null,
    });
  }

  if (response && response.ok === false) {
    return setDownloadState({
      active: false,
      phase: "Download failed",
      error: response.error || "Download failed.",
    });
  }

  return setDownloadState({
    active: false,
    phase: "Complete",
    percent: 100,
    error: null,
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.action) {
    return false;
  }

  if (msg.action === "registerLectureDownloadUrl") {
    setDownloadState({
      available: true,
      url: msg.url,
      title: sanitizeFilename(msg.title),
      tabId: sender.tab && sender.tab.id,
      phase: lectureDownloadState.active ? lectureDownloadState.phase : "Ready",
      error: null,
    });

    sendResponse({ ok: true, state: getPublicDownloadState() });
    return false;
  }

  if (msg.action === "getLectureDownloadState") {
    sendResponse({ ok: true, state: getPublicDownloadState() });
    return false;
  }

  if (msg.action === "relayLectureDownloadProgress") {
    setDownloadState({
      jobId: msg.jobId || lectureDownloadState.jobId,
      tabId: msg.tabId || lectureDownloadState.tabId,
      phase: msg.phase || lectureDownloadState.phase,
      downloaded: Number.isFinite(msg.downloaded) ? msg.downloaded : lectureDownloadState.downloaded,
      total: Number.isFinite(msg.total) ? msg.total : lectureDownloadState.total,
      percent: Number.isFinite(msg.percent) ? msg.percent : lectureDownloadState.percent,
      active: !["Complete", "Canceled"].includes(msg.phase),
    });

    return false;
  }

  if (msg.action === "cancelLectureDownload") {
    (async () => {
      await ensureOffscreenDocument();
      const response = await chrome.runtime.sendMessage({
        action: "offscreenCancelLectureDownload",
        jobId: msg.jobId || lectureDownloadState.jobId,
      });

      setDownloadState({
        active: false,
        phase: "Canceled",
        percent: 0,
        error: null,
      });

      sendResponse(response || { ok: true });
    })().catch((error) => {
      const message = error && error.message ? error.message : String(error);
      sendResponse({ ok: false, error: message });
    });

    return true;
  }

  if (msg.action === "downloadGeneratedFile") {
    downloadFile({
      url: msg.url,
      filename: `${sanitizeFilename(msg.title)}.${msg.extension || "ts"}`,
      saveAs: false,
    })
      .then((downloadId) => sendResponse({ ok: true, downloadId }))
      .catch((error) => {
        const message = error && error.message ? error.message : String(error);
        sendResponse({ ok: false, error: message });
      });

    return true;
  }

  if (msg.action === "startLectureDownload") {
    startLectureDownload({
      url: msg.url,
      title: msg.title,
      tabId: (sender.tab && sender.tab.id) || msg.tabId,
      jobId: msg.jobId,
    })
      .then((state) => sendResponse({ ok: !state.error, state }))
      .catch((error) => {
        const message = error && error.message ? error.message : String(error);
        console.error("SwiftSkip download failed:", message);

        downloadFile({
          url: msg.url || lectureDownloadState.url,
          filename: `${sanitizeFilename(msg.title || lectureDownloadState.title)}.m3u8`,
          saveAs: false,
        }).catch((downloadError) => {
          console.error("SwiftSkip fallback download failed:", downloadError);
        });

        const state = setDownloadState({
          active: false,
          phase: "Download failed",
          error: message,
          fallback: "m3u8",
        });
        sendResponse({ ok: false, error: message, state });
      });

    return true;
  }

  if (msg.action !== "downloadLecture") {
    return false;
  }

  startLectureDownload({
    url: msg.url,
    title: msg.title,
    tabId: sender.tab && sender.tab.id,
    jobId: msg.jobId,
  })
    .then((state) =>
      sendResponse({
        ok: !state.error,
        fallback: state.fallback,
        canceled: state.phase === "Canceled",
        state,
      }),
    )
    .catch((error) => {
      const message = error && error.message ? error.message : String(error);
      console.error("SwiftSkip download failed:", message);
      sendResponse({ ok: false, error: message });
    });

  return true;
});
